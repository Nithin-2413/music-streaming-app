import 'main.dart' as m;

void main() async {
  m.isFdroidBuild = true;
  m.main();
}
