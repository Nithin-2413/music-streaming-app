library sorts_controller;

// Deprecated
part '../types/sort_types/song_sort_type.dart';

// Media Sorts
part '../types/sort_types/audio_sort_type.dart';
part '../types/sort_types/album_sort_type.dart';
part '../types/sort_types/artist_sort_type.dart';
part '../types/sort_types/playlist_sort_type.dart';
part '../types/sort_types/genre_sort_type.dart';
