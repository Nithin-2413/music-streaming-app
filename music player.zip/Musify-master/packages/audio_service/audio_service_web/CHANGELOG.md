## 0.1.1

* Better detection of browser support (@nt4f04uNd)

## 0.1.0

* Upgrade to v0.1.0 of audio_service_platform_interface.

## 0.0.1

* Move web implementation to federated plugin model (@keaganhilliard)
* Initial release.
