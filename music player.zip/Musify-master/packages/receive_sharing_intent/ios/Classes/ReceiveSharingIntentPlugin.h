#import <Flutter/Flutter.h>

@interface ReceiveSharingIntentPlugin : NSObject<FlutterPlugin>
@end
